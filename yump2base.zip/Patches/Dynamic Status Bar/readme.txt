INSTALLATION:
	Simply run asar on DynamicStatusBarPatch.asm, while keeping StatusBarInit.asm, StatusBarMain.asm, and the 'data' folder in the same place in relation to the patch.
	The file in "uberasm" should be placed in the 'library' folder in uberasmtool.

HOW TO INSERT YOUR CUSTOM STATUS CODE:
	The format is basically the same as Uberasm patch.
	StatusBarInit.asm contains code that is run once when the statusbar type is called.
	StatusBarMain.asm contains code that is run every frame the statusbar is active.
		Note: this include once when the Init routine is called, which assures all needed assets are present immediately.
	
	*************************************************************************************************
	IMPORTANT: X/Y INDEX REGISTERS ARE __16-BIT__ DURING INIT AND MAIN STATUSBAR ROUTINES BY DEFAULT.
	*************************************************************************************************

HOW TO ACTIVATE YOUR CUSTOM STATUS CODE:
	During levelasm, there are separate ways to activate your statusbar depending if it's during 'init' or 'main'.
	For levelinit:
		write the following routine as such:
		
			lda #$xx
			jsl Statusbar_Set
			
		where xx is the ID of your statusbar. This is needed during levelinit because otherwise, the statusbar wouldn't update until the mosiac is complete.
		
	For levelmain:
		simply write the value of the new statusbar to $0EF9. Everything will be handled automatically.

MACRO INFO:
	There are a variety of available macros to play with for programming. They should be fairly flexible for useage.

General note:
	<Offset>: In practice, use the various defined labels to specify location:
		!BAR_ROW_X where X is a number 0-4 indicating which horizontal row of tiles to use.
		!BAR_TILE_X where X is a number 0-1F hex, indicating which tile per row to use.
		Example:
			%Vanilla_Score(!BAR_ROW_1+!BAR_TILE_0)
			
		This example starts writing to the second row from the top, at the leftmost tile of the screen.

------------------------------------------------
%Vanilla_Time(Offset)
	Processes the in-level timer and draws a 3-digit value the screen.

%Vanilla_Score(Offset)
	Caps the player's score, and draws a 6-digit value to the screen.

%Vanilla_Coins(Offset)
	Processes incrementing and rolling-over coins, and draws a 2-digit value to the screen.
	
%Vanilla_Lives(Offset)
	Caps the player's lives, and draws a 2-digit value to the screen.

%Vanilla_Bonus_Stars(Offset)
	Processes when to roll-over bonus stars and activate bonus game flag, and draws a special graphic of 2-digit values to the screen.

%Vanilla_Player_Name(Offset)
	Draw's luigi's name tiles if player 2 is in use.

%Vanilla_Yoshi_Coins(Offset)
	Draws the corresponding number of yoshi coins to the screen.

%Vanilla_Reserve_Item(Xpos,Ypos)
	<Xpos>: 8-bit value specifying where on the screen to draw the reserve item.
	<Ypos>: same as above but for y position.
	Draws the reserve item, if one is available, at the specified coordinates.

%Timer_Flashing_Warning(OffsetTime,OffsetNumber)
	<OffsetTime> and <OffsetNumber> are in the same format as <Offset>, just they are specifying two different offsets.
	Super Status Bar's included routine which flashes the timer if it's under 100 seconds and plays warning beeps if under 10 seconds.

%All_Yoshi_Coin(Offset)
	Same as %Vanilla_Yoshi_Coins but draws ALL0 (0 == coin symbol) when all 5 coins are collected.

%Generic_Draw_Stripe(Offset,DataPtr)
	<DataPtr>: 24-bit address specifying start of data.
	Draws a specified block of tiles, in pseudo-stripe format.
	basically, the format is exactly the same except the first byte should contain a !BAR_ROW_X command, and the second byte a !BAR_TILE_X command.
	no FF terminator is needed in this case.
	Example:
		
		StripeData1:
		db $00,$07 ; No RLE, horizontal direction, 7+1 bytes to upload
		db $FC,$38,$0A,$31,$0B,$31,$FC,$38

%Generic_Draw_Stripe_Hardcoded(DataPtr)
	Similar to above, but uses full 4-byte headers. the first two bytes are formatted in the same way as <Offset>, with example below:
	
		StripeData2:
		dw !BAR_ROW_0+!BAR_TILE_0
		db $40,$0F
		db $FC,$38
		dw !BAR_ROW_0+!BAR_TILE_1F
		db $80,$03
		db $01,$31,$02,$31
		db $FF
	
%Draw_8bit_2digit(Offset,Address)
	<Address>: 24-bit address to read value from.
	This will take the value in the given address, and write a decimal 2-digit number at the specified offset.
	If the value is less than 10, the tens place will be clear. Similar behavior applies to any above digits for below commands.
	If the value is greater than 99, it is clipped down to 99.
	
%Draw_8bit_3digit(Offset,Address)
	Very similar to above, the difference being that 3 tiles are drawn with a hundreds digit included.
	The value is clipped at 999.
	
%Draw_16bit_3digit(Offset,Address)
	This will take the value in the given address as a 16-bit value to calculate a decimal 3-digit number at the specified offset.
	The value is clipped at 999.
	
%Draw_16bit_4digit(Offset,Address)
	Very similar to above, with 4 tiles drawn with a thousands digit.
	The value is clipped at 9999.
	
%Draw_8bit_2address(Offset,Address)
	This will take the value specified in <Address> and <Address>+1 and write out what each digit corresponds to.
	No clipping is applied in this case, actually.

%Draw_8bit_1address(Offset,Address)
	Similar to above with 1 tile. essentially, draw 1 tile based on address space.

%Generic_Draw_Sprite(OAM_Offset,DataPtr)
	<OAM_Offset>: the table indice to $0200 to start drawing OAM tiles to. Is clipped within range of $0200-$03FF, and clipped to be a multiple of 4 to align proper.
	<DataPtr>: 24-bit address to write OAM data from.
	The OAM data is formatted as such:
	The first byte is the number of tiles to draw. ($01 == draw one tile)
	Then each tile to draw has 5 bytes of data associated with it:
		db (X-position),(Y-position),(Tile),(YXPPCCCT),(Size/X-position high bit)
		
	Example:
		
		SpriteDrawTest:
		db $04 ; Draw 4 tiles
		db $70,$07,$00,%00110000,$02 ; draws around the reserve item, with tile 00 (which will show mario's top half.)
		db $80,$07,$00,%01110000,$02
		db $70,$17,$00,%10110000,$02
		db $80,$17,$00,%11110000,$02