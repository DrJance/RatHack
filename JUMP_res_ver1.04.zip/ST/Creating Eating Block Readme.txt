-----------------------------------------------------------------------------
Creating/Eating Block sprite by Davros
-----------------------------------------------------------------------------
A custom sprite that's based on the original Creating/Eating Block sprite. It 
will use the default paths that the original sprite uses. Depending on it's 
X position, it will either create or eat the blocks. 

creating_eating_block.asm
creating_eating_block2.asm

creating_eating_block.asm it's the standard sprite.  
creating_eating_block2.asm is the same as above but Mario can ride it.

The Creating/Eating Block sprite uses this Ram Address in order to choose a 
path depending on the submap:

SUBMAP	    LDA $1F11,y             
		    CMP #$01 
               
It can easily be changed to any Ram Address, for example:

SUBMAP	    LDA $14AF,y             
		    CMP #$01 

By changing it to $14AF it will choose a path depending on the On/Off setting 
and you can have two different paths on the same level.
-----------------------------------------------------------------------------
Creating/Eating Block Directional Data
-----------------------------------------------------------------------------
The paths can be changed and expanded if you manage to understand the format: 

One byte per command, XY, where: 
X = Number of times to go in direction Y. 
Y = 0,1,2,3 (Right, left, down, up) 
FF terminates the sprite.

SUBMAP_PATH     

dcb $10,$13,$10,$13,$10,$13,$10,$13,$10,$13,$10,$13,$10,$13,$10,$13
dcb $F0,$F0,$20,$12,$10,$12,$10,$12,$10,$12,$10,$12,$10,$12,$10,$12
dcb $D0,$C3,$F1,$21,$22,$F1,$F1,$51,$43,$10,$13,$10,$13,$10,$13,$F0
dcb $F0,$F0,$60,$32,$60,$32,$71,$32,$60,$32,$61,$32,$70,$33,$10,$33
dcb $10,$33,$10,$33,$10,$33,$F0,$10,$F2,$52,$FF			
                    
OVERWORLD_PATH  

dcb $80,$13,$10,$13,$10,$13,$10,$13,$60,$23,$20,$23,$B0,$22,$A1,$22
dcb $A0,$22,$A1,$22,$C0,$13,$10,$13,$10,$13,$10,$13,$10,$13,$10,$13
dcb $10,$13,$F0,$F0,$F0,$52,$50,$33,$50,$32,$50,$33,$50,$22,$50,$33
dcb $F0,$50,$82,$FF

Keep in mind that the sprite must not touch an object along it's path.
-----------------------------------------------------------------------------
Credits

Mikeyk
For making Sprite Tool

Goldensunboy
For the info on the Creating/Eating Block sprite

Davros
For the disassembly of the Creating/Eating Block sprite
-----------------------------------------------------------------------------